/*
 * common.c
 *
 *  Created on: 2025. 9. 8.
 *      Author: user
 */




