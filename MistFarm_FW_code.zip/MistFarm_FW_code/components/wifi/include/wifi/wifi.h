/*
 * wifi.h
 *
 *  Created on: 2025. 9. 7.
 *      Author: user
 */

#ifndef COMPONENTS_WIFI_H_
#define COMPONENTS_WIFI_H_
#include "mistfarm/config.h"




#endif /* COMPONENTS_WIFI_H_ */
